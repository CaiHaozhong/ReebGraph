#include <QObject>
#include <stdio.h>
class A : public QObject
{
	Q_OBJECT
public slots:
	void print()
	{
		printf("This is A slot\n");
	}
};

class B : public QObject
{
	Q_OBJECT

signals:
	void trigger();

public:
	void run()
	{
		emit trigger();
	}
};