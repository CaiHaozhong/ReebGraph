#pragma once
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>
#include <vector>
using namespace std;
typedef OpenMesh::TriMesh_ArrayKernelT<> Mesh;
struct PointAndEdge
{
	Mesh::Point pos;
	OpenMesh::EdgeHandle edge;
	PointAndEdge(Mesh::Point p, OpenMesh::EdgeHandle e):pos(p),edge(e){}
};
typedef vector<PointAndEdge> IsoLine;
class ClassifiedIsoLine
{
	ClassifiedIsoLine(){}
public:
	ClassifiedIsoLine(Mesh* mesh, const IsoLine& isoLine)
	{
		_cur = 0;
		this->_mesh = mesh;
		_isoLineSize = isoLine.size();
		classify(isoLine);
	}

	IsoLine* getNextIsoLine()
	{
		if (_cur < _isoLines.size())
		{
			return &(_isoLines[_cur++]);	
		}
		else
			return NULL;
	}

	int isoLineCount()
	{
		return _isoLineSize;
	}
private:
	vector<IsoLine> _isoLines;
	int _cur;
	int _isoLineSize;
	Mesh* _mesh;
	void classify(const IsoLine& isoLine)
	{
		bool *isVisited = new bool[_isoLineSize];
		memset(isVisited,0,_isoLineSize);
		int unVisit = 0;
		while(unVisit != -1)
		{
			IsoLine ring;
			ring.push_back(isoLine.at(unVisit));
			isVisited[unVisit] = true;
			while(true)
			{
				bool hasFound = false;

				for(int u = 0; u < _isoLineSize; u++)
				{
					if(isVisited[u] == false)
					{
						PointAndEdge testP = isoLine.at(u);
						for (int i = 0 ; i < ring.size(); i++)
						{
							if(isAdjancent(ring.at(i),testP))
							{
								ring.push_back(testP);
								isVisited[u] = true;
								hasFound = true;
								break;
							}
						}
						if(hasFound)
							break;
					}

				}
				if(hasFound == false)
					break;

			}
			_isoLines.push_back(ring);
			unVisit = _getNextUnVisited(isVisited);
		}
		delete [] isVisited;

	}
	int _getNextUnVisited(bool isVisited[])
	{
		for(int i = 0; i < _isoLineSize; i++)
		{
			if(isVisited[i] == false)
			{
				return i;
			}
		}
		return -1;
	}

	bool isAdjancent(const PointAndEdge& pe1, const PointAndEdge& pe2)
	{
		OpenMesh::HalfedgeHandle h0 = _mesh->halfedge_handle(pe1.edge,0);
		OpenMesh::HalfedgeHandle h1 = _mesh->halfedge_handle(pe1.edge,1);
		// 		OpenMesh::VertexHandle v0 = _mesh->to_vertex_handle(h0);
		// 		OpenMesh::VertexHandle v1 = _mesh->to_vertex_handle(h1);
		// 		for(auto ve_it = _mesh->ve_iter(v0); ve_it.is_valid(); ve_it++)
		// 		{
		// 			if(*ve_it == pe2.edge)
		// 				return true;
		// 		}
		// 		for (auto ve_it = _mesh->ve_iter(v1); ve_it.is_valid(); ve_it++)
		// 		{
		// 			if(*ve_it == pe2.edge)
		// 				return true;
		// 		}
		// 		return false;

		auto faceHandle0 = _mesh->face_handle(h0);
		auto faceHandle1 = _mesh->face_handle(h1);
		if(faceHandle0.is_valid())
		{
			for(auto fe_it = _mesh->fe_iter(faceHandle0); fe_it.is_valid(); fe_it++)
			{
				if(*fe_it != pe1.edge)
				{
					if(*fe_it == pe2.edge)
						return true;
				}
			}
		}
		if(faceHandle1.is_valid())
		{
			for(auto fe_it = _mesh->fe_iter(faceHandle1); fe_it.is_valid(); fe_it++)
			{
				if(*fe_it != pe1.edge)
				{
					if(*fe_it == pe2.edge)
						return true;
				}
			}
		}

		return false;
	}
};