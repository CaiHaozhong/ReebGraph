#pragma once
#include <vector>
#include "geodesic_algorithm_exact.hh"
typedef std::vector<double> PointList;
typedef std::vector<unsigned> FaceList;
typedef std::vector<double> GeodesicDistanceArray;
template<class MeshOFOpenMesh>
class GeodesicAdapter
{
public:
	GeodesicAdapter()
	{
		_algorithm = nullptr;
	}
	GeodesicAdapter(PointList& pointList, FaceList& faceList)
	{
		_mesh.initialize_mesh_data(pointList,faceList);
		_algorithm = new geodesic::GeodesicAlgorithmExact(&_mesh);
	}

	
	//************************************
	// FullName:        GeodesicAdapter<MeshOFOPENMESH>::GeodesicAdapter
	// Access:          public 
	// Returns:         
	// Parameter:       MeshOFOPENMESH & _meshOfOpenMesh
	// Description:     Don't have to invoke addSource(...) out of this constrctor
	//************************************
	GeodesicAdapter(MeshOFOpenMesh& _meshOfOpenMesh)
	{
		PointList pointList;
		FaceList faceList;
		int source;
		double maxYValue = -1000000;
		int curver = 0;

		for (OpenMesh::PolyConnectivity::VertexIter v_it = _meshOfOpenMesh.vertices_begin(); v_it != _meshOfOpenMesh.vertices_end(); ++v_it)
		{
			auto point = _meshOfOpenMesh.point(*v_it);				
			for (int i = 0; i < 3; i++)
			{
				pointList.push_back(point.values_[i]);
			}
			if(point.values_[1] > maxYValue)
			{
				maxYValue = point.values_[2];
				source = curver;
			}
			curver ++;			
		}

		for(OpenMesh::PolyConnectivity::FaceIter f_it = _meshOfOpenMesh.faces_begin(); f_it != _meshOfOpenMesh.faces_end(); ++f_it)
		{				
			for(OpenMesh::PolyConnectivity::FaceVertexIter fv_it = _meshOfOpenMesh.fv_iter(*f_it); fv_it.is_valid(); ++fv_it)
			{
				OpenMesh::ArrayKernel::VertexHandle vertexHandle = *fv_it;
				int index = vertexHandle.idx();

				faceList.push_back(index);				
			}
		}

		_mesh.initialize_mesh_data(pointList,faceList);
		_algorithm = new geodesic::GeodesicAlgorithmExact(&_mesh);
		addSource(source);
	}
	
	~GeodesicAdapter()
	{
		if(_algorithm != nullptr)
			delete _algorithm;
	}

	void addSource(unsigned int s)
	{
		_all_sources.push_back(&_mesh.vertices()[s]);
	}

	void computeGeodesicFromSource(GeodesicDistanceArray& ret)
	{
		if(!_algorithm)
			return;

		if(_all_sources.size() == 0)
			return;

		_algorithm->propagate(_all_sources);

		ret.clear();
		for(unsigned i = 0; i < _mesh.vertices().size(); ++i)
		{
			geodesic::SurfacePoint p(&_mesh.vertices()[i]);		

			double distance;
			unsigned best_source = _algorithm->best_source(p,distance);		//for a given surface point, find closets source and distance to this source

			ret.push_back(distance);
		}
	}
private:
	geodesic::Mesh _mesh;
	geodesic::GeodesicAlgorithmExact* _algorithm;
	std::vector<geodesic::SurfacePoint> _all_sources;
};

