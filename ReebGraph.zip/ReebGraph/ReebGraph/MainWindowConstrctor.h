#pragma once
#include <QMessageBox>
#include <QMainWindow>
#include <QMenuBar>
#include "MeshViewer.h"
#include "OpenGLViewer.h"
#include "ReebGraph.h"
#include <QGLWidget>
class MainWindowConstructor : public QObject
{
	Q_OBJECT
public:	
	MainWindowConstructor(QMainWindow& _mainWin):_mainWindow(_mainWin){}

	~MainWindowConstructor()
	{
		if(_meshViewer != nullptr)
			delete _meshViewer;
	}
	void create_menu()
	{
		createFileMenu();
		createFunctionMenu();
	}

	void create_mainView()
	{
		_meshViewer = new MeshViewer;
		_mainWindow.setCentralWidget(_meshViewer);
		currentView = _MeshViewer;
	}

	void createFileMenu()
	{
		QMenuBar* menuBar = _mainWindow.menuBar();
		QMenu* fileMenu = menuBar->addMenu(_mainWindow.tr("&File"));

		_openAct = new QAction(_mainWindow.tr("&Open mesh..."), &_mainWindow);
		_openAct->setShortcut(_mainWindow.tr("Ctrl+O"));
		_openAct->setStatusTip(_mainWindow.tr("Open a mesh file"));
		fileMenu->addAction(_openAct);
		

		_clearAct = new QAction(_mainWindow.tr("&clear mesh..."), &_mainWindow);
		_clearAct->setStatusTip(_mainWindow.tr("Clear current mesh"));
		fileMenu->addAction(_clearAct);

	}

	void createFunctionMenu()
	{
		QMenuBar* menuBar = _mainWindow.menuBar();
		QMenu* funcMenu = menuBar->addMenu(_mainWindow.tr("&Function"));

		_showGeodesicAct = new QAction(_mainWindow.tr("&Show Geodesic..."), &_mainWindow);		
		_showGeodesicAct->setStatusTip(_mainWindow.tr("Show Geodesic"));

		_showReebGraphAct = new QAction(_mainWindow.tr("&Show ReebGraph..."), &_mainWindow);		
		_showReebGraphAct->setStatusTip(_mainWindow.tr("Show ReebGraph"));

		funcMenu->addAction(_showGeodesicAct);
		funcMenu->addAction(_showReebGraphAct);
	}

	//************************************
	// FullName:        MainWindowConstructor::construct
	// Access:          public 
	// Returns:         void
	// Description:     ���������ڣ����������˵��������棬����UI���¼�
	//************************************
	void construct()
	{
		create_menu();
		create_mainView();
		connectEvent();
	}


	//************************************
	// FullName:        MainWindowConstructor::connectEvent
	// Access:          public 
	// Returns:         void
	// Description:     ���ӽ����ϵĲ���
	//************************************
	void connectEvent()
	{
		QObject::connect(_openAct,SIGNAL(triggered()),this,SLOT(openMesh()));
		QObject::connect(_clearAct,SIGNAL(triggered()),this,SLOT(clearMesh()));
		QObject::connect(_showGeodesicAct, SIGNAL(triggered()),this,SLOT(showGeodesic()));
		QObject::connect(_showReebGraphAct, SIGNAL(triggered()),this,SLOT(translateToReebgraphView()));
	}

	void setMainView(QWidget* view)
	{
		_mainWindow.setCentralWidget(view);
	}

	

private:
	QMainWindow& _mainWindow;

	QAction* _openAct;
	QAction* _clearAct;
	QAction* _showGeodesicAct;
	QAction* _showReebGraphAct;
	MeshViewer* _meshViewer;

	typedef enum{
		_MeshViewer,
		_OpenGLViewer
	} CurrentView;

	CurrentView currentView;
public slots:
	void translateToReebgraphView()
	{
		if(MeshData::getInstance()->getMesh() == nullptr)
		{
			QMessageBox::warning(NULL, "warning", "You have to open a mesh named 'dapangzi.obj'", QMessageBox::Ok, QMessageBox::Ok);
			return;
		}
		ReebGraph* reebGraph = new ReebGraph;
		OpenGLView* opv = new OpenGLView;
		opv->setIsoContainer(reebGraph->isoLineContainer);
		opv->setClassifiedIsoContainer(reebGraph->classifiedIsoLineContainer);
		_meshViewer->setParent(nullptr);
		this->setMainView(opv);
		currentView = _OpenGLViewer;
	}

	void openMesh()
	{
		if(currentView != _MeshViewer)
		{
			setMainView(_meshViewer);
		}
		_meshViewer->open_mesh_gui();
	}
	void clearMesh()
	{
		if(currentView != _MeshViewer)
		{
			setMainView(_meshViewer);
		}
		_meshViewer->clear_current_mesh();
		MeshData::getInstance()->setMesh(nullptr);
	}
	void showGeodesic()
	{
		if(MeshData::getInstance()->getMesh() == nullptr)
		{
			QMessageBox::warning(NULL, "warning", "You have to open a mesh named 'dapangzi.obj'", QMessageBox::Ok, QMessageBox::Ok);
			return;
		}
		if(currentView != _MeshViewer)
		{
			setMainView(_meshViewer);
		}
		_meshViewer->showGeodesic();
	}
};