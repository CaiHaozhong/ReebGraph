#include "MeshData.h"

MeshData* MeshData::self = nullptr;