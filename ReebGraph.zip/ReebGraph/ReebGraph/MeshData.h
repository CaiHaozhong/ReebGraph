#pragma  once
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>

typedef OpenMesh::TriMesh_ArrayKernelT<> Mesh;

class MeshData
{
public:
	Mesh* getMesh()
	{
		return _mesh;
	}

	void setMesh(Mesh* m)
	{
		this->_mesh = m;
	}

	static MeshData* getInstance()
	{
		if(self == nullptr)
		{
			self = new MeshData;
			return self;
		}
		else
			return self;
	}
private:
	Mesh* _mesh;
	static MeshData* self;


	MeshData()
	{
		_mesh = nullptr;
	}

	MeshData(Mesh* m)
	{
		_mesh = m;
	}

	~MeshData()
	{
		if (_mesh != nullptr)
		{
			delete _mesh;		
			_mesh = nullptr;
		}
	}
};