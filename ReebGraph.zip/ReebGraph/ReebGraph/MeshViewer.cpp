#include "MeshViewer.h"
#include <GL/glu.h>
#include <GL/gl.h>
MeshViewer::MeshViewer(void)
{
	indices_array = nullptr;
	_granularity = 20;
}

MeshViewer::MeshViewer( QWidget* parent ) :QGLViewerWidget(parent)
{

	indices_array = nullptr;
	_granularity = 20;
}


MeshViewer::~MeshViewer(void)
{
	if(indices_array)
		delete [] indices_array;
}


void MeshViewer::draw_scene( const std::string& _draw_mode )
{
// 	drawReebGraph();
// 	return;
	if (_draw_mode == "Wireframe")
	{
		glDisable(GL_LIGHTING);		
		glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);		
		drawMesh();
	}

	else if (_draw_mode == "Solid Flat")
	{
		glEnable(GL_LIGHTING);
		glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
		glShadeModel(GL_FLAT);
		drawMesh();
	}

	else if (_draw_mode == "Solid Smooth")
	{
		glEnable(GL_LIGHTING);
		glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
		glShadeModel(GL_SMOOTH);
		drawMesh();
	}
	
	else if(_draw_mode == "Geodesic")
	{
		glDisable(GL_LIGHTING);
		
		//glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
		drawPoint();
	}
}

void MeshViewer::readMesh( const QString& fileName )
{
	_mesh.request_vertex_normals();
	OpenMesh::IO::Options opt;
	if(!OpenMesh::IO::read_mesh(_mesh,fileName.toStdString(),opt))
	{

		QString msg = "Cannot read mesh from file:\n '";
		msg += fileName;
		msg += "'";
		QMessageBox::critical( NULL, windowTitle(), msg);
	}
	if ( !opt.check( OpenMesh::IO::Options::VertexNormal ) )
	{
		// we need face normals to update the vertex normals
		_mesh.request_face_normals();
		// let the mesh update the normals
		_mesh.update_normals();
		// dispose the face normals, as we don't need them anymore
		_mesh.release_face_normals();
	}		

	Mesh *newMesh = new Mesh(_mesh);
	MeshData::getInstance()->setMesh(newMesh);

	_mesh.add_property(_geo);

	prepareDrawMesh();

	adjustScene();

	updateGL();
	setWindowTitle(QFileInfo(fileName).fileName());
}

void MeshViewer::prepareDrawMesh()
{
	indices_array = new GLuint[_mesh.n_faces() * 3];

	//��ʼ����������,typedef��������
	typedef OpenMesh::PolyConnectivity::VertexHandle VertexHandle;
	typedef OpenMesh::PolyConnectivity::FaceHandle FaceHandle;
	typedef OpenMesh::PolyConnectivity::FaceVertexIter FaceVertexIter;

	int vi = 0;
	// 		int ni = 0;
	// 		std::for_each(_mesh.vertices_begin(), _mesh.vertices_end(), [&](const VertexHandle v_it){
	// 			Mesh::Point p = _mesh.point(v_it);
	// 			vertices_array[vi++] = p.values_[0];
	// 			vertices_array[vi++] = p.values_[1];
	// 			vertices_array[vi++] = p.values_[2];
	// 
	// 			Mesh::Normal n = _mesh.normal(v_it);
	// 			normals_array[ni++] = n.values_[0];
	// 			normals_array[ni++] = n.values_[1];
	// 			normals_array[ni++] = n.values_[2];
	// 		});
	// 		assert(vi == _mesh.n_vertices() * 3);
	// 		assert(ni == _mesh.n_vertices() * 3);
	// 		vi = 0;
	std::for_each(_mesh.faces_begin(), _mesh.faces_end(), [&](const FaceHandle f_it){
		int t = 0;
		for (FaceVertexIter face_v_it = _mesh.fv_iter(f_it); face_v_it.is_valid(); ++face_v_it)
		{
			t++;
			indices_array[vi++] = face_v_it->idx();
		}
		assert(t == 3, "not triangle face");
	});		


	makeCurrent();
	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
		/* Problem: glewInit failed, something is seriously wrong. */
		fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
	}
	fprintf(stdout, "Status: Using GLEW %s\n", glewGetString(GLEW_VERSION));
	glGenBuffers(VBO_SIZE,_vbo);
	glBindBuffer(GL_ARRAY_BUFFER,_vbo[VBO_VERTEX]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * 3 * _mesh.n_vertices() * 1 , _mesh.points(), GL_STATIC_DRAW);
	glEnableClientState(GL_VERTEX_ARRAY);		
	glVertexPointer(3,GL_FLOAT,0,0);

	glBindBuffer(GL_ARRAY_BUFFER, _vbo[VBO_NORMAL]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * 3 * _mesh.n_vertices() * 1 , _mesh.vertex_normals(), GL_STATIC_DRAW);
	glEnableClientState(GL_NORMAL_ARRAY);
	glNormalPointer(GL_FLOAT,0, 0);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _vbo[VBO_INDEX]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,sizeof(GLuint) * 3 * _mesh.n_faces(),indices_array,GL_STATIC_DRAW);

	//delete [] indices_array;
}

void MeshViewer::drawMesh()
{
	if(_mesh.n_vertices() == 0)
		return;

	glClear(GL_COLOR_BUFFER_BIT);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _vbo[VBO_INDEX]);
	glDrawElements(GL_TRIANGLES, _mesh.n_faces() * 3, GL_UNSIGNED_INT, 0);
}

void MeshViewer::drawPoint()
{
	if(_mesh.n_vertices() == 0)
		return;

	glClear(GL_COLOR_BUFFER_BIT);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _vbo[VBO_INDEX]);
	glPointSize(2);
	// 		std::fstream f("colorModel.txt",std::ios::app);
	// 		for (auto f_it = _mesh.faces_begin(); f_it != _mesh.faces_end(); f_it++)
	// 		{			
	// 			for (auto fv_it = _mesh.fv_iter(*f_it); fv_it.is_valid(); fv_it++)
	// 			{
	// 				Mesh::Color c = _mesh.color(*fv_it);
	// 				Mesh::Point p = _mesh.point(*fv_it);
	// 				f << (int)(c.values_[0]) << ' ' << (int)(c.values_[1]) << ' ' << (int)(c.values_[2]) << ' ';
	// 				f << p.values_[0] << ' ' << p.values_[1] << ' ' << p.values_[2] << std::endl;
	// 			}			
	// 		}	
	// 		f.close();
	glDrawElements(GL_POINTS, _mesh.n_faces() * 3, GL_UNSIGNED_INT, 0);
}

void MeshViewer::adjustScene()
{
	// bounding box
	Mesh::ConstVertexIter vIt(_mesh.vertices_begin());
	Mesh::ConstVertexIter vEnd(_mesh.vertices_end());      

	OpenMesh::Vec3f bbMin, bbMax;

	bbMin = bbMax = OpenMesh::vector_cast<OpenMesh::Vec3f>(_mesh.point(*vIt));

	for (size_t count=0; vIt!=vEnd; ++vIt, ++count)
	{
		bbMin.minimize( OpenMesh::vector_cast<OpenMesh::Vec3f>(_mesh.point(*vIt)));
		bbMax.maximize( OpenMesh::vector_cast<OpenMesh::Vec3f>(_mesh.point(*vIt)));
	}


	// set center and radius
	set_scene_pos( (bbMin+bbMax)*0.5, (bbMin-bbMax).norm()*0.5 );
}

void MeshViewer::computeVertexColor( const GeodesicDistanceArray& result )
{
	typedef OpenMesh::ArrayKernel::VertexHandle VertexIndex;
	typedef std::tuple<VertexIndex, double> IndexDis;
	typedef std::vector<IndexDis> IndexDisArray;
	IndexDisArray indexDisArray;
	int t = 0;		
	for(auto v_it = _mesh.vertices_begin(); v_it != _mesh.vertices_end(); ++v_it)
		indexDisArray.push_back(std::tie(*v_it,result.at(t++)));

	std::sort(indexDisArray.begin(),indexDisArray.end(),[](const IndexDis& a, const IndexDis& b) -> bool {
		double disOfa,disOfb;
		std::tie(std::ignore,disOfa) = a;
		std::tie(std::ignore,disOfb) = b;
		return disOfa < disOfb;
	});

	int num = 15;
	double minDis,maxDis;
	std::tie(std::ignore,minDis) = indexDisArray.at(0);
	std::tie(std::ignore,maxDis) = indexDisArray.at(indexDisArray.size()-1);
	double interval = (maxDis-minDis)/num;
	// 		double limiter = 254.0/(maxDis - minDis);
	// 		_mesh.request_vertex_colors();
	// 		for (int i = 0; i < indexDisArray.size(); i++)
	// 		{
	// 			VertexIndex index;
	// 			double dis;
	// 			std::tie(index,dis) = indexDisArray.at(i);
	// 			_mesh.set_color(index,Mesh::Color((unsigned char)((dis-minDis)*limiter),50,50));
	// 		}

	std::vector<std::vector<IndexDis> > classificationContainer;

	double base = 0;
	std::vector<IndexDis> classification;
	for (int i = 0; i < indexDisArray.size(); i++)
	{
		double dis;
		IndexDis cur = indexDisArray.at(i);
		std::tie(std::ignore, dis) = cur;

		if(dis - base <= interval)
			classification.push_back(indexDisArray.at(i));
		else
		{
			classificationContainer.push_back(classification);
			classification.clear();
			base = dis;
			classification.push_back(cur);
		}
	}
	classificationContainer.push_back(classification);

	Mesh::Color colorList[5] = {Mesh::Color(255,0,0), Mesh::Color(255,255,255), Mesh::Color(0,255,255),Mesh::Color(0,0,255), Mesh::Color(0,255,0)};
	//show		
	_mesh.request_vertex_colors();
	for (int i = 0; i < classificationContainer.size(); i++)
	{
		Mesh::Color color = colorList[i%5];			

		std::vector<IndexDis> classification = classificationContainer.at(i);
		std::for_each(classification.begin(), classification.end(),[&](const IndexDis& item){
			VertexIndex index;
			std::tie(index, std::ignore) = item;

			_mesh.set_color(index,color);				
		});
	}
}

bool MeshViewer::storeToTS( GeodesicDistanceArray& disarray, const char* file )
{
	std::ofstream output(file);
	if(!output.is_open())
		return false;

	output << _mesh.n_vertices() << ' ' << _mesh.n_faces() << std::endl;

	int cur = 0;
	for(OpenMesh::PolyConnectivity::VertexIter v_it = _mesh.vertices_begin(); v_it != _mesh.vertices_end(); ++v_it)
	{
		Mesh::Point p = _mesh.point(*v_it);
		output << p.values_[0] << ' ' << p.values_[1] << ' ' << p.values_[2] << ' ' << disarray.at(cur++) << std:: endl;
	}
	for (OpenMesh::PolyConnectivity::FaceIter f_it = _mesh.faces_begin(); f_it != _mesh.faces_end(); ++f_it)
	{
		for (OpenMesh::PolyConnectivity::FaceVertexIter fv_it = _mesh.fv_iter(*f_it); fv_it.is_valid(); ++fv_it)
		{
			output << *fv_it << ' ';
		}
		output << std::endl;
	}
	output.close();
	return true;
}

std::tuple<int,int> MeshViewer::readNodes( std::ifstream& input, GLuint** indexArray, unsigned char** colorArray, GLuint** arcIndexArray )
{
	unsigned int nodeSize, arcSize;
	input >> nodeSize >> arcSize;
	GLuint* localIndexArray = new GLuint[nodeSize];
	unsigned char* localColorArray = new unsigned char[nodeSize * 3];
	GLuint* localArcIndexArray = new GLuint[nodeSize*2];
	typedef enum{
		MINIMA,
		SADDLE,
		MAXIMA,
		ALL
	} CriticalType;
	unsigned char _color[ALL][3] = {{255,0,0}, {0,255,0}, {0,0,255}};
	float _ignore;
	std::string typeString;
	for(int i = 0; i < nodeSize; i++)
	{
		input >> localIndexArray[i] >> _ignore >> typeString;
		CriticalType type = MAXIMA;
		if(typeString == "MINIMA")
			type = MINIMA;
		else if(typeString == "SADDLE")
			type = SADDLE;
		localColorArray[i*3] = _color[type][0];
		localColorArray[i*3+1] = _color[type][1];
		localColorArray[i*3+2] = _color[type][2];
	}
	for (int i = 0; i < arcSize; i+=2)
	{
		input >> localArcIndexArray[i] >> localArcIndexArray[i+1]  >> _ignore;
	}
	*indexArray = localIndexArray;
	*colorArray = localColorArray;
	*arcIndexArray = localArcIndexArray;
	return std::tie(nodeSize,arcSize);
}

void MeshViewer::open_mesh_gui()
{
	QString fileName = QFileDialog::getOpenFileName(this,
		tr("Open mesh file"),
		tr(""),
		tr("OBJ Files (*.obj);;"
		"OFF Files (*.off);;"
		"STL Files (*.stl);;"
		"All Files (*)"));
	if (!fileName.isEmpty())
		readMesh(fileName);
}

void MeshViewer::clear_current_mesh()
{
	if(MeshData::getInstance()->getMesh() == nullptr)
	{
		QMessageBox::warning(NULL, "warning", "You have to open a mesh named 'dapangzi.obj'", QMessageBox::Ok, QMessageBox::Ok);
		return;
	}
	_mesh.clear();
	glDeleteBuffers(VBO_SIZE,_vbo);
	glClear(GL_COLOR_BUFFER_BIT);
	glDisableClientState(GL_VERTEX_ARRAY);
}

void MeshViewer::showGeodesic()
{
	GeodesicAdapter<Mesh> geodesicAdapter(_mesh);
	GeodesicDistanceArray result;
	geodesicAdapter.computeGeodesicFromSource(result);			
	//bool isSuccess = storeToTS(result,"dapangzipolysmooth.ts");

	computeVertexColor(result);

	GLuint colorVbo;
	glGenBuffers(1,&colorVbo);
	glBindBuffer(GL_ARRAY_BUFFER,colorVbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(unsigned char) * 3 * _mesh.n_vertices(), _mesh.vertex_colors(), GL_STATIC_DRAW);
	glEnableClientState(GL_COLOR_ARRAY);
	glColorPointer(3,GL_UNSIGNED_BYTE, 0, 0);

	setDrawMode(1);
}

void MeshViewer::showReebGraph()
{
	typedef unsigned char VertexColor;

	bool suc = OpenMesh::IO::read_mesh(_mesh,"dapangzi.obj",OpenMesh::IO::Options());
	if(!suc) return;

	adjustScene();

	std::ifstream input("output.rg");
	if(!input.is_open()) return;


	GLuint* indexArray;
	VertexColor* colorArray;
	GLuint* arcIndexArray;
	std::tuple<int,int> sizes;
	sizes = readNodes(input,&indexArray,&colorArray,&arcIndexArray);

	std::tie(nodeSize,arcSize) = sizes;

	makeCurrent();
	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
		/* Problem: glewInit failed, something is seriously wrong. */
		fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
	}
	fprintf(stdout, "Status: Using GLEW %s\n", glewGetString(GLEW_VERSION));

	glGenBuffers(sizeof(localVbo)/sizeof(GLuint),localVbo);

	glBindBuffer(GL_ARRAY_BUFFER, localVbo[0]);
	glBufferData(GL_ARRAY_BUFFER,3 * sizeof(float) * _mesh.n_vertices(), _mesh.points(),GL_STATIC_DRAW);
	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer(3,GL_FLOAT,0,0);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,localVbo[1]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLuint) * nodeSize, indexArray, GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,localVbo[2]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, 2* sizeof(GLuint) * arcSize, arcIndexArray, GL_STATIC_DRAW);

	glBindBuffer(GL_ARRAY_BUFFER,localVbo[3]);
	glBufferData(GL_ARRAY_BUFFER, 3 * sizeof(unsigned char) * nodeSize, colorArray, GL_STATIC_DRAW);
	glEnableClientState(GL_COLOR_ARRAY);
	glColorPointer(3,GL_UNSIGNED_BYTE,0,0);

	/** draw **/


	delete [] indexArray;
	delete [] colorArray;
	delete [] arcIndexArray;
	glEnable(GL_POINT_SMOOTH);
	glHint(GL_POINT_SMOOTH,GL_NICEST);
	updateGL();
}

void MeshViewer::drawReebGraph()
{
	if(_mesh.n_vertices() == 0)
		return;

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,localVbo[2]);
	glDisableClientState(GL_COLOR_ARRAY);
	glDrawElements(GL_LINES,2*arcSize, GL_UNSIGNED_INT,0);

	glPointSize(3.0f);
	//glEnableClientState(GL_COLOR_ARRAY);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,localVbo[1]);
	glDrawElements(GL_POINTS, nodeSize, GL_UNSIGNED_INT, 0);
	glPointSize(1.0f);
	
}

void MeshViewer::computeGeodesic()
{
	GeodesicAdapter<Mesh> geodesicAdapter(_mesh);
	GeodesicDistanceArray result;
	geodesicAdapter.computeGeodesicFromSource(result);
	int k = 0;
	for(OpenMesh::PolyConnectivity::VertexIter v_it = _mesh.vertices_begin(); v_it != _mesh.vertices_end(); v_it++)
	{
		_mesh.property(_geo,*v_it) = result.at(k++);
	}
}