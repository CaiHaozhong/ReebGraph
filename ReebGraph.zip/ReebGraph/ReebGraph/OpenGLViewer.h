#pragma once
#include <fstream>
#include "QGLViewerWidget.hh"
#include "ClassifiedIsoLine.h"

#include <stdlib.h>
using namespace std;

class OpenGLView : public QGLViewerWidget
{
	Q_OBJECT
public:

	void draw_scene(const std::string& _draw_mode)
	{
  		glPointSize(1.0f);
//  		drawAllRingWhite();
// 		float co[3] = {1.0f, 0.0f, 0.0f};
// 		int line = (curRingToHighLight++)%isoContainer.size();
// 		glPointSize(3.0f);
// 		drawRing(line, co);
		drawAllToplogyRing();
		glPointSize(4.0f);
		int line = (curRingToHighLight++)%isoContainer.size();
		drawTopologyRing(line);
	}
	void drawRing(int i, float color[])
	{
		IsoLine line = isoContainer.at(i);
		drawRing(line,color);
	}

	void drawRing(const IsoLine& ring, float color[])
	{
		glColor3fv(color);
		glBegin(GL_POINTS);
		for (int i = 0; i < ring.size(); i++)
		{
			Mesh::Point p = ring.at(i).pos;

			glVertex3fv(p.values_);	
		}
		glEnd();
	}
	void drawAllRingWhite()
	{
		for (int i = 0; i < isoContainer.size(); i++)
		{
			float co[3] = {1.0f, 1.0f, 1.0f};
			drawRing(i,co);
		}
	}

	void drawTopologyRing(int i)
	{
		ClassifiedIsoLine cil = classifiedIsoLineContainer.at(i);
		IsoLine *line = cil.getNextIsoLine();
		int j = 0;
		while (line != NULL)
		{
			drawRing(*line,_color[j++]);
			line = cil.getNextIsoLine();
		}
	}

	void drawAllToplogyRing()
	{
		int size = classifiedIsoLineContainer.size();
		for (int i = 0; i < size; i++)
		{
			drawTopologyRing(i);
		}
	}

	void drawNode()
	{
		glPointSize(3.0f);
		for (int i = 0; i < isoContainer.size(); i++)
		{
			float co[3];
			for (int c = 0; c < 3; c++)
			{
				int r = rand();
				co[c] = (r%200) / 200.0f;
				srand(r);
			}
			glColor3fv(co);
			
			Mesh::Point center = Mesh::Point(0,0,0);
			for (int j = 0; j < isoContainer.at(i).size(); j++)
			{
				Mesh::Point p = isoContainer.at(i).at(j).pos;
				center += p;							
			}
			center /= isoContainer.at(i).size();
			glBegin(GL_POINTS);
			glVertex3fv(center.values_);	
			glEnd();

		}
	}
	void setIsoContainer(const vector<IsoLine>& container)
	{
		this->isoContainer = container;
		curRingToHighLight = 0;
	}

	void setClassifiedIsoContainer(const vector<ClassifiedIsoLine>& container)
	{
		this->classifiedIsoLineContainer = container;
		initColorList();
		curRingToHighLight = 0;
	}

	void adjustScene()
	{
		OpenMesh::Vec3f bbMin, bbMax;

		bbMin = bbMax = OpenMesh::vector_cast<OpenMesh::Vec3f>(isoContainer.at(0).at(0).pos);

		for (int i = 0; i < isoContainer.size(); i++)
		{
			for (int j = 0; j < isoContainer.at(i).size(); j++)
			{
				Mesh::Point p = isoContainer.at(i).at(j).pos;
				bbMin.minimize( OpenMesh::vector_cast<OpenMesh::Vec3f>(p) );
				bbMax.maximize( OpenMesh::vector_cast<OpenMesh::Vec3f>(p) );
			}
			
		}


		// set center and radius
		set_scene_pos( (bbMin+bbMax)*0.5, (bbMin-bbMax).norm()*0.5 );
	}
	
	void initializeGL()
	{
		QGLViewerWidget::initializeGL();
		adjustScene();
	}

	void initColorList()
	{
		float value[2] = {0.8f,0.1f};
		int c = 0;
		for(int i = 0; i < 2; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				for (int k = 1; k >= 0; k--)
				{
					_color[c][0] = value[i];
					_color[c][1] = value[j];
					_color[c][2] = value[k];
					c += 1;

				}
			}
		}
	}
public:
	vector<IsoLine> isoContainer;
	vector<ClassifiedIsoLine> classifiedIsoLineContainer;
	int curRingToHighLight;
	float _color[8][3];
};