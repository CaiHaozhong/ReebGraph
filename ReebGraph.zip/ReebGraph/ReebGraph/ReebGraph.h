#pragma once
#include <vector>
#include "GeodesicAdapter.hh"
#include <OpenMesh/Core/Geometry/VectorT.hh>
#include "ClassifiedIsoLine.h"
#include "MeshData.h"
typedef OpenMesh::Vec3d Vector3D;

struct ReebNode
{	
	Vector3D pos;
	std::vector<ReebNode*> children;

	typedef enum{
		TYPE_NORMAL,
		TYPE_CLA,//����
		TYPE_HIP, //��
		TYPE_INVALIDE
	} ReebNodeType;

	ReebNodeType type()
	{
		if(children.size() == 1)
			return TYPE_NORMAL;
		else if(children.size() == 2)
			return TYPE_HIP;
		else if(children.size() == 3)
			return TYPE_CLA;
		else
			return TYPE_INVALIDE;
	}

};
using namespace std;
class ReebGraph
{
	
public:

	vector<IsoLine> isoLineContainer;

	vector<ClassifiedIsoLine> classifiedIsoLineContainer;

 	ReebGraph(void)
	{
		_granularity = 20;
		_mesh = MeshData::getInstance()->getMesh();
		_mesh->add_property(_geo);
		printf("computeGeodesic...\n");
		computeGeodesic();
		printf("computeReebGraph...\n");
		computeReebGraph();
		printf("classify...\n");
		classify();
	}

// 	ReebGraph(ReebNode* rootNode, ReebNode* claNode, ReebNode* hipNode);
// 	~ReebGraph(void){}
// 
// 	vector<ReebNode> allNodes;
private:

// 	ReebNode* mRootNode;
// 	ReebNode* mClaNode;
// 	ReebNode* mHipNode;
// 
// 	double mInterval;
	int _granularity;

	Mesh* _mesh;

	OpenMesh::VPropHandleT<double> _geo;//ÿ������Ĳ��������

	void computeGeodesic()
	{
		GeodesicAdapter<Mesh> geodesicAdapter(*_mesh);
		GeodesicDistanceArray result;
		geodesicAdapter.computeGeodesicFromSource(result);
		int k = 0;
		for(OpenMesh::PolyConnectivity::VertexIter v_it = _mesh->vertices_begin(); v_it != _mesh->vertices_end(); v_it++)
		{
			_mesh->property(_geo,*v_it) = result.at(k++);
		}
	}

	void computeReebGraph()
	{

		isoLineContainer.resize(_granularity);
		double maxGeo = -1;
		for(OpenMesh::PolyConnectivity::VertexIter v_it = _mesh->vertices_begin(); v_it != _mesh->vertices_end(); v_it++)
		{
			double geo = _mesh->property(_geo,*v_it);
			if(geo > maxGeo)
				maxGeo = geo;
		}
		double step = maxGeo / (_granularity + 1);//���뻷֮��ľ���


		for(auto e_it = _mesh->edges_begin(); e_it != _mesh->edges_end(); e_it++)
		{
			OpenMesh::HalfedgeHandle h0 = _mesh->halfedge_handle(*e_it,0);
			OpenMesh::HalfedgeHandle h1 = _mesh->halfedge_handle(*e_it,1);
			OpenMesh::VertexHandle v0 = _mesh->to_vertex_handle(h0);
			OpenMesh::VertexHandle v1 = _mesh->to_vertex_handle(h1);
			Mesh::Point beginPoint = _mesh->point(v0);
			Mesh::Point endPoint = _mesh->point(v1);
			double beginGeo = _mesh->property(_geo,v0);
			double endGeo = _mesh->property(_geo,v1);
			for (int i = 0; i < _granularity; i++)
			{
				double geo = step + i * step;
				if(geo > beginGeo && geo < endGeo || geo > endGeo && geo < beginGeo)
				{
					Mesh::Point interpolatePoint = beginPoint + (endPoint - beginPoint) * (geo-beginGeo)/(endGeo-beginGeo);
					isoLineContainer[i].push_back(PointAndEdge(interpolatePoint,*e_it));
				}
			}
		}
	}
	void classify()
	{
		int size = isoLineContainer.size();
		classifiedIsoLineContainer.clear();
		for (int i = 0; i < size; i++)
		{
			classifiedIsoLineContainer.push_back(ClassifiedIsoLine(_mesh,isoLineContainer.at(i)));
		}
	}
};

