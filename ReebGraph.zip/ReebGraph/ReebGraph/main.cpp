#include <QApplication>
#include <QMainWindow>
#include <QString>
#include <stdio.h>
#include <QMenuBar>
#include "AB.h"
#include "MeshViewer.h"
#include "MainWindowConstrctor.h"

#include <OpenMesh/Core/IO/MeshIO.hh>
#include <OpenMesh/Core/Mesh/PolyMesh_ArrayKernelT.hh>
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>
#include "OpenGLViewer.h"
#include <vector>
void generateFace()
{
	typedef OpenMesh::PolyMesh_ArrayKernelT<> _Mesh;
	OpenMesh::IO::Options op;
	_Mesh _mesh;
	if(OpenMesh::IO::read_mesh(_mesh,"dapangzipoly.obj",op))
	{
		std::ofstream output("faceListPoly.txt");
		if(!output.is_open())
			return ;
		std::vector<OpenMesh::VertexHandle> vertexContainer;
		int counter = 0;
		for (OpenMesh::PolyConnectivity::FaceIter f_it = _mesh.faces_begin(); f_it != _mesh.faces_end(); ++f_it)
		{
			vertexContainer.clear();
			for (OpenMesh::PolyConnectivity::FaceVertexIter fv_it = _mesh.fv_iter(*f_it); fv_it.is_valid(); ++fv_it)
			{
				vertexContainer.push_back(*fv_it);				
			}
			if(vertexContainer.size() == 4)
			{
				for (auto iter = vertexContainer.begin(); iter != vertexContainer.end() ;iter++)
				{
					output << *iter << ' ';
				}				
				output << std::endl;
				counter++;
			}			
		}
		output << counter << std::endl;
		output.close();
	}	
	OpenMesh::TriMesh_ArrayKernelT<> _TriMesh;
	printf("Tri\n");
	OpenMesh::IO::read_mesh(_TriMesh,"dapangzipolyFrom3Dsmax.obj",op);
	getchar();
	exit(0);
}
Mesh _mesh;
OpenMesh::VPropHandleT<double> _geo;//ÿ������Ĳ��������
int _granularity = 20;
vector<IsoLine> isoLineContainer;
vector<ClassifiedIsoLine> classifiedIsoLineContainer;
void readMesh(const QString& fileName)
{
	_mesh.request_vertex_normals();
	OpenMesh::IO::Options opt;
	if(!OpenMesh::IO::read_mesh(_mesh,fileName.toStdString(),opt))
	{
		printf("Cannot read mesh from file\n");
	}
	if ( !opt.check( OpenMesh::IO::Options::VertexNormal ) )
	{
		// we need face normals to update the vertex normals
		_mesh.request_face_normals();
		// let the mesh update the normals
		_mesh.update_normals();
		// dispose the face normals, as we don't need them anymore
		_mesh.release_face_normals();
	}

	_mesh.add_property(_geo);
}
void computeGeodesic()
{
	GeodesicAdapter<Mesh> geodesicAdapter(_mesh);
	GeodesicDistanceArray result;
	geodesicAdapter.computeGeodesicFromSource(result);
	int k = 0;
	for(OpenMesh::PolyConnectivity::VertexIter v_it = _mesh.vertices_begin(); v_it != _mesh.vertices_end(); v_it++)
	{
		_mesh.property(_geo,*v_it) = result.at(k++);
	}
}

void computeReebGraph()
{

	isoLineContainer.resize(_granularity);
	double maxGeo = -1;
	for(OpenMesh::PolyConnectivity::VertexIter v_it = _mesh.vertices_begin(); v_it != _mesh.vertices_end(); v_it++)
	{
		double geo = _mesh.property(_geo,*v_it);
		if(geo > maxGeo)
			maxGeo = geo;
	}
	double step = maxGeo / (_granularity + 1);//���뻷֮��ľ���


	for(auto e_it = _mesh.edges_begin(); e_it != _mesh.edges_end(); e_it++)
	{
		OpenMesh::HalfedgeHandle h0 = _mesh.halfedge_handle(*e_it,0);
		OpenMesh::HalfedgeHandle h1 = _mesh.halfedge_handle(*e_it,1);
		OpenMesh::VertexHandle v0 = _mesh.to_vertex_handle(h0);
		OpenMesh::VertexHandle v1 = _mesh.to_vertex_handle(h1);
		Mesh::Point beginPoint = _mesh.point(v0);
		Mesh::Point endPoint = _mesh.point(v1);
		double beginGeo = _mesh.property(_geo,v0);
		double endGeo = _mesh.property(_geo,v1);
		for (int i = 0; i < _granularity; i++)
		{
			double geo = step + i * step;
			if(geo > beginGeo && geo < endGeo || geo > endGeo && geo < beginGeo)
			{
				Mesh::Point interpolatePoint = beginPoint + (endPoint - beginPoint) * (geo-beginGeo)/(endGeo-beginGeo);
				isoLineContainer[i].push_back(PointAndEdge(interpolatePoint,*e_it));
			}
		}
	}
}
void classify()
{
	int size = isoLineContainer.size();
	classifiedIsoLineContainer.clear();
	for (int i = 0; i < size; i++)
	{
		classifiedIsoLineContainer.push_back(ClassifiedIsoLine(&_mesh,isoLineContainer.at(i)));
	}
}
int main(int argc, char** argv)
{
	//generateFace();
// 	readMesh("dapangzi.obj");
// 	computeGeodesic();
// 	computeReebGraph();
// 	classify();
	QApplication::setColorSpec(QApplication::CustomColor);
	QApplication app(argc,argv);
	glutInit(&argc,argv);
	QMainWindow mainWin;
	mainWin.resize(640,480);
	MainWindowConstructor constructor(mainWin);
	constructor.construct();
	//OpenGLView* opv = new OpenGLView;
	//opv->setIsoContainer(isoLineContainer);
	//opv->setClassifiedIsoContainer(classifiedIsoLineContainer);
	//constructor.setMainView(opv);
	mainWin.show();
	return app.exec();
}
