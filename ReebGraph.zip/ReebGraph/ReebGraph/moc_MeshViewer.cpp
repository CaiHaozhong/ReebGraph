/****************************************************************************
** Meta object code from reading C++ file 'MeshViewer.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "MeshViewer.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MeshViewer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MeshViewer[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x0a,
      28,   11,   11,   11, 0x0a,
      49,   11,   11,   11, 0x0a,
      83,   69,   64,   11, 0x0a,
     191,  149,  129,   11, 0x0a,
     251,   11,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MeshViewer[] = {
    "MeshViewer\0\0open_mesh_gui()\0"
    "clear_current_mesh()\0showGeodesic()\0"
    "bool\0disarray,file\0"
    "storeToTS(GeodesicDistanceArray&,const char*)\0"
    "std::tuple<int,int>\0"
    "input,indexArray,colorArray,arcIndexArray\0"
    "readNodes(std::ifstream&,GLuint**,unsigned char**,GLuint**)\0"
    "showReebGraph()\0"
};

void MeshViewer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MeshViewer *_t = static_cast<MeshViewer *>(_o);
        switch (_id) {
        case 0: _t->open_mesh_gui(); break;
        case 1: _t->clear_current_mesh(); break;
        case 2: _t->showGeodesic(); break;
        case 3: { bool _r = _t->storeToTS((*reinterpret_cast< GeodesicDistanceArray(*)>(_a[1])),(*reinterpret_cast< const char*(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 4: { std::tuple<int,int> _r = _t->readNodes((*reinterpret_cast< std::ifstream(*)>(_a[1])),(*reinterpret_cast< GLuint**(*)>(_a[2])),(*reinterpret_cast< unsigned char**(*)>(_a[3])),(*reinterpret_cast< GLuint**(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< std::tuple<int,int>*>(_a[0]) = _r; }  break;
        case 5: _t->showReebGraph(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MeshViewer::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MeshViewer::staticMetaObject = {
    { &QGLViewerWidget::staticMetaObject, qt_meta_stringdata_MeshViewer,
      qt_meta_data_MeshViewer, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MeshViewer::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MeshViewer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MeshViewer::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MeshViewer))
        return static_cast<void*>(const_cast< MeshViewer*>(this));
    return QGLViewerWidget::qt_metacast(_clname);
}

int MeshViewer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGLViewerWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
